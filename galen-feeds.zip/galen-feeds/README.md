# Galen Grup · Otomatik Listing Feed Sistemi

Tek bir üründen Truck1, Autoline ve MachineSeeker için XML feed üretir.
Sen `catalog.json`'u güncelliyorsun → Cloudflare otomatik build alıyor → 3 feed canlıya çıkıyor →
platformlar o URL'leri kendileri çekiyor. Bir kere kur, sonsuza dek otomatik.

```
catalog.json  ──node build.js──►  public/feeds/truck1.xml
                                   public/feeds/autoline.xml
                                   public/feeds/machineseeker.xml
```

---

## 1) GitHub'a yükle

1. github.com'da yeni bir repo aç: **galen-feeds** (private yapabilirsin).
2. Bu klasördeki tüm dosyaları o repoya yükle (web arayüzünden "Upload files" ile sürükle-bırak yeterli).
   - `build.js`, `package.json`, `catalog.json`, `.gitignore`, `public/_headers`

## 2) Cloudflare Pages'e bağla

1. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
2. **galen-feeds** reposunu seç.
3. Build ayarları:
   - **Framework preset:** None
   - **Build command:** `node build.js`
   - **Build output directory:** `public`
4. **Save and Deploy.**

Birkaç dakika sonra feed'lerin canlı:
```
https://galen-feeds.pages.dev/feeds/truck1.xml
https://galen-feeds.pages.dev/feeds/autoline.xml
https://galen-feeds.pages.dev/feeds/machineseeker.xml
```

## 3) (Opsiyonel) Kendi alan adın

Cloudflare Pages projesi → **Custom domains** → `feeds.hb450kesim.com` ekle.
Sonra URL'ler şöyle olur: `https://feeds.hb450kesim.com/feeds/truck1.xml`

---

## 4) Platformlara feed URL'ini ver

| Platform | Nerede | Not |
|---|---|---|
| **MachineSeeker** | Hesap → **Data Import → Automatic Import** → feed URL'ini gir | Dealer/Professional plan (10+ makine) gerekir. Önce dosyanı doğrulama aracında test et. |
| **Truck1** | Bayi hesabı açıp **data exchange / feed** iste (hesap yöneticin veya partners@truck1.eu) | Sana kendi şemalarını verirler — gerekirse `build.js`'teki `exportTruck1` fonksiyonunu ona göre düzenle. |
| **Autoline** | Truck1 ile aynı grup; aynı bayi feed sürecinden geçer | `exportAutoline` fonksiyonunu onların şemasına göre ayarla. |

> **Önemli:** Şu anki XML alan adları genel B2B equipment standardına göre yazıldı.
> Her platform sana resmi şemasını verdiğinde, ilgili fonksiyonu `build.js` içinde
> düzenleyip repoya push'la — Cloudflare otomatik yeni feed'i üretir.

---

## 5) Ürün ekleme / güncelleme

İki yol var:

**A. Dashboard'dan (kolay):** `galen_listing_console.html` aracında ürünleri düzenle,
"Publish to GitHub" butonuna bas → `catalog.json` otomatik güncellenir → Cloudflare build alır.

**B. Elle:** `catalog.json`'u doğrudan repoda düzenle. Her ürün bir JSON objesi.
`"status": "draft"` veya `"status": "sold"` yaparsan o ürün feed'e çıkmaz.

Her push'tan sonra feed otomatik yeniden üretilir; platformlar bir sonraki çekişte günceli alır.

---

## Lokal test

```bash
node build.js
# public/feeds/ altında 3 XML üretilir
```

## catalog.json alan referansı

| Alan | Açıklama |
|---|---|
| `ref` | Benzersiz ürün kodu (GG-2026-001) |
| `status` | active / draft / sold — sadece active feed'e çıkar |
| `category`, `condition`, `make`, `model`, `year` | Temel |
| `price`, `currency`, `vat` | Fiyat |
| `weight`, `hours`, `carrier`, `width`, `capacity`, `material` | Teknik |
| `city`, `country`, `delivery` | Lokasyon/teslim |
| `title_en/tr`, `desc_en/tr` | Başlık ve açıklama |
| `images` | HTTPS URL listesi |
| `contact`, `phone`, `email` | Satıcı iletişim |
